import './assets/service-worker.ts-DdzoVv3n.js';
